/**
 * 提供推荐, 查找等服务
 */
Recommender = function() {
	/*
		注意：这个地方不能写127.0.0.1，这样的话只能在本地调试！因为其它终端载入js页面后解析到的也是127.0.0.1，这样就回去访问终端本身
		这个地方要么写一个域名，要么写一个不会改变的绝对ip地址。
	*/
	var url = 'http://127.0.0.1:10000/api';
//	var url = 'http://192.168.0.104:10000/api';
	
    var mask = new Mask();

    /**
     * 内部的回调函数, 主要用于处理mask
     */
    var internCallback = function(raw, opt) {
        console.log(['response', raw]);
        mask.hide();
        var data = {
            status: raw[0][0].code,
            content: raw[0][1],
        };
        if(typeof data.status == 'undefined' || data.status == null) {
            data.status = 1; // UNKNOWN_ERROR
        }
        opt.fn.call(opt.scope, data)
    };
    /**
     * 发送请求
     */
    var request = function(method, params, callback, scope) {
        console.log(['request', method, params]);
        var m = (params != null)? [[method, params]]: [[method]];
        var p = {
            m: Ext.encode(m),
            a: new Date().getTime(),
        };
        JSONP.request({
            url: url,
            callbackKey: 'c',
            params: p,
            callback: internCallback,
            scope: this,
            opt: {
                fn: callback,
                scope: scope,
            },
        });
    }
    /**
     * 执行推荐请求 callback(data)
     */
    this.recommend = function(dist, priceIndex, notVisited, geo, start, len, callback, scope, maskElement) {
        if(!geo) {
			return;
        }
        mask.show(maskElement, '正在为您推荐 ...');
        p = {
            dist: dist,
            lo:geo.longitude,
            la:geo.latitude,
            len: len,
            start: start,
        };
        var price = getPriceRange(priceIndex);
        if(typeof price.min == 'number') {
            p.minPay = price.min;
        }
        if(typeof price.max == 'number') {
            p.maxPay = price.max;
        }
        if(notVisited) {
            p.notVisited = true;
        }
        request('recommend', p, callback, scope);
    }
    /**
     * 创建新用户
     */
    this.newUser = function(callback, scope, maskElement) {
        mask.show(maskElement, '正在创建新用户 ...');
        request('newuser', null, callback, scope);
    }
    /**
     * 获取打分记录
     * startId 为开始遍历的餐馆Id(不包括), 为 null 时从头获取
     */
    this.myRates = function(startTime, startPlace, len, callback, scope, maskElement) {
        mask.show(maskElement, '正在查询 ...');
        p = {
            len: len
        };
        if(startTime != null) {
            p.startTime = startTime;
        }
        if(startPlace != null) {
            p.startPlace = startPlace;
        }
        request('myrates', p, callback, scope);
    }
    /**
     * 打分
     */
    this.rate = function(id, rate, callback, scope, maskElement) {
        mask.show(maskElement, '正在发送打分请求 ...');
        request('rate', {
            id: id,
            rate: rate
        }, callback, scope);
    }
    /**
     * 检查用户是否已登录
     */
    this.checkLogin = function(callback, scope, maskElement) {
        mask.show(maskElement, '正在检查登录状态 ...');
        request('checklogin', null, callback, scope);
    }
    /**
     * 注销当前用户
     */
    this.logout = function(callback, scope, maskElement) {
        mask.show(maskElement, '正在注销 ...');
        request('logout', null, callback, scope);
    }
    /**
     * 解除绑定
     */
    this.unbind = function(accountType, accountId, callback, scope, maskElement) {
        mask.show(maskElement, '解除绑定 ...');
        request('unbind', {
            type: accountType,
            id: accountId,
        }, callback, scope);
    }
    /**
     * 绑定通行证
     */
    this.bindNet = function(user, pass, isLogin, callback, scope, maskElement) {
    	mask.show(maskElement, '正在登录 ...');
        request('bindntes', {
            user: user,
            pass: MD5(pass),
            login: isLogin,
        }, callback, scope);
    }
}
