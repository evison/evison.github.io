/**
 * 描述 Starup 面板
 */
StartPanel = function(hidden, recommender) {
    /**
     * 面板UI组件
     */
    var panel = new Ext.Panel({
        hidden: hidden,
        layout: {
            type: 'fit',
            align: 'center',
            pack: 'center'
        },
        bubbleEvents: ['recommend', 'personalize'],
        dockedItems: [{
            dock : 'top',
            xtype: 'toolbar',
            title: 'Chicker'
        }
        ],
        items: [{
            xtype: 'form',
            items: [{
                xtype: 'fieldset',
                title: '第一次使用?',
                items: [{
                    xtype: 'field',
                    margin: 5,
                    html: '您可以立刻通过一个简单的步骤表达自己的个性化需求, 从而得到更加准确的搜索结果',
                },{
                    xtype: 'button',
                    ui: 'action',
                    margin: 5,
                    text: '个性化',
                    handler: function(b, e) {
                        newUser('personalize');
                    },
                },{
                    xtype: 'field',
                    margin: 5,
                    html: '也可以暂时跳过, 在使用过程中逐渐积累个性化信息',
                },{
                    xtype: 'button',
                    margin: 5,
                    text: '跳过',
                    handler: function(b, e) {
                        newUser('recommend');
                    },
                }
                ]
            }/*,{
                xtype: 'fieldset',
                title: '您也可以通过以下帐号直接登录',
                items: [{
                    xtype: 'button',
                    ui: 'confirm',
                    margin: 5,
                    text: '通行证',
                    bubbleEvents: ['net', 'recommend'],
                    handler: function(b, e) {
                        // login
                        this.fireEvent('net', true, function() {
                            this.fireEvent('recommend', true);
                        }, this);
                    },
                }
                ]
            }*/
            ]
        }
        ],
    });

    /**
     * 创建新用户
     */
    var newUser = function(event) {
        recommender.newUser( function(data) {
            if(data.status != 0) {
                Ext.Msg.alert('错误', '创建新用户失败, status = ' + data.status);
                return;
            }
            CurrentUser.load(data.content);
            this.fireEvent(event, true);//这个地方是对的，当前面显示要去打分的提示是，后面也应该执行，也就是准备好被打分的餐馆
            if(event == 'personalize') {
                Ext.Msg.alert('欢迎!', '请为10个餐厅打分以便帮助我们了解您的喜好.');
            }
        }, panel, panel.body);
    }
    /**
     * 返回底层的UI组件
     */
    this.getComponent = function() {
        return panel;
    }
    /**
     * show()
     */
    this.show = function(animation) {
        panel.show(animation);
    }
    /**
     * hide()
     */
    this.hide = function(animation) {
        panel.hide(animation);
    }
}
