/**
 * 打分面板
 */
RatePanel = function(hidden, location, recommender) {
    /**
     * 面板UI组件
     */
    var msgBar = new Ext.Panel({
        dock: 'bottom',
        style: {
            background: '#B0D0FF',
            opacity: 0.9,
            'font-size': '.8em',
            'line-height':1.5,
        },
    });
    var detail = new SilmarilDetail({
        rateHandler: {
            fn: function(value) {
                this.rateCurrent(value);
            },
            scope: this,
        }
    });
    var titleBar = new Ext.Toolbar({
        dock : 'top',
        title: 'Chicker',
        items: [{
            xtype: 'button',
            text: '后退',
            ui: 'back',
            bubbleEvents: 'back',
            handler: function(b, e) {
                this.fireEvent('back');
            },
        },{
            xtype: 'spacer'
        },{
            xtype: 'button',
            iconCls: 'arrow_up',
            iconMask: true,
            ui: 'plain',
            handler: function(b, e) {
                this.prev();
            },
            scope: this,
        }],
    });
    var panel = new Ext.Panel({
        height: '100%',
        hidden: hidden,
        bubbleEvents: 'recommend',
        dockedItems: [titleBar, msgBar],
        items: [detail]
    });

    var rests = [];
    var current = 0;

    /**
     * 返回底层的UI组件
     */
    this.getComponent = function() {
        return panel;
    }
    /**
     * show()
     */
    this.show = function(animation) {
        panel.show(animation);
    }
    /**
     * hide()
     */
    this.hide = function(animation) {
        panel.hide(animation);
    }
    /**
     * 显示消息
     */
    this.info = function(msg) {
        msgBar.update('<p style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;">' + msg + '</p>');
        panel.doComponentLayout();
    }
    /**
     * 更新显示指定餐馆细节
     */
    this.update = function() {
        var rest = null;
        if(current >= 0 && current < rests.length) {
            rest = rests[current];
            Ext.applyIf(rest, rest.rest);
        };
        var n = rests.length == 0? 0: current + 1;
        titleBar.setTitle('Chicker ' + n + '/' + rests.length);
        detail.update(rest);
    }
    /**
     * next
     */
    this.next = function() {
        if(rests.length == 0) {
            Msg.overlay('对不起', '没有可以查看的推荐');
        } else if(current == rests.length-1) {
            Ext.Msg.show({
                title : '完成了!',
                msg : '您可以立刻查看推荐, 或者继续打分',
                buttons: [{
                    text: '查看推荐',
                    itemId: 'recommend'
                },{
                    text: '继续打分',
                    itemId: 'more'
                }],
                fn: function(button) { 
                    if(button == 'recommend') {/*通过调用recommend函数给出推荐*/
                        panel.fireEvent('recommend');
                    } else {/*通过调用自己的recommend函数继续打分(该函数会调用全局的recommend函数得到候选列表)*/
                        this.recommend(true);
                    }
                },
                scope : this,
                icon: Ext.MessageBox.QUESTION
            });
        } else {
            Ext.Anim.run(detail, 'slide', {
                direction: 'up',
                duration: 200,
                autoClear: false,
                after: function() {
                    current ++;
                    this.update();
                    Ext.Anim.run(detail, 'slide', {
                        direction: 'up',
                        out: false,
                        duration: 200,
                    });
                },
                scope: this,
            })
        }
    }
    /**
     * prev
     */
    this.prev = function() {
        if(rests.length == 0) {
            Msg.overlay('对不起', '没有可以查看的推荐');
        } else if(current == 0) {
            Msg.overlay('对不起', '已经是第一条了');
        } else {
            Ext.Anim.run(detail, 'slide', {
                direction: 'down',
                duration: 200,
                autoClear: false,
                after: function() {
                    current --;
                    this.update();
                    Ext.Anim.run(detail, 'slide', {
                        direction: 'down',
                        out: false,
                        duration: 200,
                    });
                },
                scope: this,
            })
        }
    }
    /**
     * 推荐结果
     */
    this.recommend = function(more) {
        var dist = MainConfig.get('dist');
        var price = MainConfig.get('price');
        var start = more? rests.length: 0;	//作为个性化阶段使用时，初始传入的more==False，所以此时start==0。如果是由于点了more而进入该函数，则start=rests.length
        var len = 10;
        location.tryToGet( function(geoInfo) {	//获得地理位置后，传入geoInfo，回调该函数
            recommender.recommend(dist, price, true, geoInfo, 0, len, function(data) {	//调用recommender.recommend，得到推荐的data，并回调该函数
                if(data.status != 0) {
                    Ext.Msg.alert('出错了!', 'status = ' + data.status);
                    return;
                }
                if(!more) {//不是通过点击“更多”进入该函数
                    //rests = data.content.recs;
                	rests = data.content.rests;
                    //Ext.Msg.alert('rests.length = '  + rests.length);
                    if(rests == null) {
                    	Ext.Msg.alert('rests == null!!');
                        rests = [];
                    }
                    //Ext.Msg.alert('rests.length = '  + rests.length);
                    current = 0;
                    this.update();
                } else {//通过点击“更多”进入该函数
                    if(data.content.recs != null && data.content.recs.length > 0) {
                        rests = rests.concat(data.content.recs);
                        this.next();
                    } else {
                        Ext.Msg.alert('对不起', '没有更多可以查看的推荐');
                    }
                }
            }, this, panel.body);
        }, this, panel.body);
    }
    /**
     * 为当前餐馆打分
     */
    this.rateCurrent = function(value) {
        // 没去过
        if(value == 0) {
            this.next();
            return;
        }
        // 打分
        var rest = rests[current];
        recommender.rate(rest.brief.id, value, function(data) {
            if(data.status != 0) {
                Ext.Msg.alert('错误', '给' + rest.brief.name + '打分出错了, status = ' + data.status);
            }
            var self = this;
            setTimeout( function() {
                self.next();
            }, 200);
        }, this);
    }
    var needRefresh = true;
    /**
     * 设置显示(激活)时刷新
     */
    this.setNeedRefresh = function(b) {
        needRefresh = b;
    }
    /**
     * 初始化
     */
    // 位置服务
    location.listen({
        scope: this,
        fn: function(geoInfo) {
            this.info('当前位置: ' + geoInfo.address);
        }
    }, {
        scope: this,
        fn: function(geoInfo,
        bTimeout,
        bPermissionDenied,
        bLocationUnavailable,
        message) {
            this.info(message);
        }
    });
    // 控件事件
    panel.on('activate', function() {
        location.open();
        if(needRefresh) {	//初始化的时候为True
            detail.hide();
            this.recommend(false);	//调用this.recommend来产生待评分列表(跟推荐调用的是一个接口，且返回的结果格式也是一样的)
            needRefresh = false;
        }
    }, this);
}