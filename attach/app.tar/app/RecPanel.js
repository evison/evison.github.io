/**
 * 描述推荐面板
 */
RecPanel = function(hidden, location, recommender) {
    Ext.regModel('RecList', {
        fields: ['html', 'rest']
    });
    /**
     * 面板UI组件
     */
    var recList = new SilmarilList({
        itemTpl: '{html}',
        store: new Ext.data.Store({
            model: 'RecList',
        }),
        disableSelection: true,
        bubbleEvents: 'detail',
        listeners: {
            itemtap: function(c, index, item, e) {
                this.fireEvent('detail', c.getRecord(item).get('rest'));
            }
        },
        moreItem: {
            handler: function() {
                this.recommend(true);
            },
            scope: this,
            text: '更多'
        },
        emptyPrompt: '没有结果? 检查一下过滤条件吧',
    });
    var distSelect = new Ext.form.Select({
        name: 'dist',
        margin: 5,
        flex: 1,
        value: MainConfig.get('dist'),
        options: [{
            text: '500 米内',
            value: 500
        },{
            text: '1 公里内',
            value: 1000
        },{
            text: '2 公里内',
            value: 2000
        },{
            text: '5 公里内',
            value: 5000
        }
        ]
    });
    var priceOptions = [];
    for(var i = 0; i < PRICE_RANGE.length; i ++) {
        priceOptions.push({
            text: getPriceRange(i).title,
            value: i
        });
    }
    var priceSelect = new Ext.form.Select({
        name: 'price',
        margin: 5,
        flex: 1,
        value: MainConfig.get('price'),
        options: priceOptions,
    });
    var msgBar = new Ext.Panel({
        dock: 'bottom',
        style: {
            background: '#B0D0FF',
            opacity: 0.9,
            'font-size': '.8em',
            'line-height':1.5,
        },
    });
    var panel = new Ext.Panel({
        hidden: hidden,
        height: '100%',
        layout: 'fit',
        dockedItems: [{
            dock : 'top',
            xtype: 'toolbar',
            title: 'Chicker',
            items: [{
                iconCls: 'settings',
                iconMask: true,
                ui: 'plain',
                bubbleEvents: 'profile',
                handler: function(b, e) {
                    this.fireEvent('profile');
                },
            },{
                xtype: 'spacer'
            },{
                iconCls: 'refresh',
                iconMask: true,
                ui: 'plain',
                handler: function(b, e) {
                    this.recommend(false);
                },
                scope: this,
            }]
        },{
            dock: 'top',
            xtype: 'panel',
            layout: 'hbox',
            items: [
            distSelect,
            priceSelect,
            ]
        }, msgBar
        ],
        items: [
        recList
        ],
    });

    /**
     * 返回底层的UI组件
     */
    this.getComponent = function() {
        return panel;
    }
    /**
     * show()
     */
    this.show = function(animation) {
        panel.show(animation);
    }
    /**
     * hide()
     */
    this.hide = function(animation) {
        panel.hide(animation);
    }
    /**
     * 显示消息
     */
    this.info = function(msg) {
        msgBar.update('<p style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;">' + msg + '</p>');
        panel.doComponentLayout();
    }
    /**
     * 推荐结果
     */
    this.recommend = function(more) {	//在这里more==False
        var dist = distSelect.getValue();
        var price = priceSelect.getValue();
        MainConfig.set('dist', dist);
        MainConfig.set('price', price);
        var start = more? recList.getCount(): 0;
        var len = 20;
        location.tryToGet( function(geoInfo) {
            recommender.recommend(dist, price, false, geoInfo, start, len, function(data) {
                if(data.status != 0) {
                    Ext.Msg.alert('出错了!', 'status = ' + data.status);
                    return;
                }
                var rests = data.content.rests;
                if(rests == null) {
                    rests = [];
                }
                var l = [];
                for(var i = 0; i < rests.length; i ++) {
                    Ext.apply(rests[i], rests[i].rest);
                    l.push({
                        html: restToHtml(rests[i]),
                        rest: rests[i],
                    });
                }
                recList.loadData(l, more, l.length < len);
            }, this, panel.body);
        },
        this, panel.body);
    }
    var needRefresh = true;
    /**
     * 设置显示(激活)时刷新
     */
    this.setNeedRefresh = function(b) {
        needRefresh = b;
    }
    /**
     * 初始化
     */
    // 位置服务
    location.listen({
        scope: this,
        fn: function(geoInfo) {
            this.info('当前位置: ' + geoInfo.address);
        }
    }, {
        scope: this,
        fn: function(geoInfo,
        bTimeout,
        bPermissionDenied,
        bLocationUnavailable,
        message) {
            this.info(message);
        }
    });
    // 控件事件
    distSelect.on('change', function() {
        this.recommend(false);
    }, this);
    priceSelect.on('change', function() {
        this.recommend(false);
    }, this);
    panel.on('activate', function() {
        location.open();
        if(needRefresh) {
            this.recommend(false);
            needRefresh = false;
        }
    }, this);
}