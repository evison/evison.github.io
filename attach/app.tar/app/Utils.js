/**
 * 在有phonegap支持时退出程序
 */
function exitApp() {
    if(navigator.app) {
        navigator.notification.confirm('确认退出吗?', function(button) {
            if(button == 1) {
                navigator.app.exitApp();
            }
        }, 'Chicker', '确定,取消');
    }
}

/**
 * 设置按钮的状态(类似于checkbox)
 */
var setButtonState = function(button, checked) {
    if(checked) {
        button.addCls('x-button-active');
    } else {
        button.removeCls('x-button-active');
    }
}
/**
 * 评分描述: 0-6
 */
RATE_TITLES = ['没去过', '很差', '较差', '一般', '不错', '很好', '想去'];
/**
 * 由评分返回文字描述的级别
 */
function getRateLevel(rate) {
    var i = Math.round(rate);
    if(i < 0) {
        i = 0;
    }
    if(i >= RATE_TITLES.length) {
        i = RATE_TITLES.length - 1;
    }
    return i;
}

/**
 * 由评分返回文字描述
 */
function getRateTitle(rate) {
    return RATE_TITLES[getRateLevel(rate)];
}

/**
 * 价格区间
 */
PRICE_RANGE = [{
    min:null,
    max:null,
    title:'不限价格'
},{
    min:0, // include
    max:20, // exclude, 下同
    title:'0 - 20 元'
},{
    min:20,
    max:50,
    title:'20 - 50 元'
},{
    min:50,
    max:100,
    title:'50 - 100 元'
},{
    min:100,
    max:200,
    title:'100 - 200 元'
},{
    min:200,
    max:null,
    title:'200 元以上'
}];
/**
 * 由索引号返回对应价格区间
 */
function getPriceRange(index) {
    return PRICE_RANGE[index];
}

/**
 * 绑定帐号类型常量
 */
BindingType = {
    NTES: 0,
    SINA: 1,
    /**
     * 返回类型名称
     */
    getName: function(type) {
        switch(type) {
            case BindingType.NTES:
                //return '通行证';
            	return '本地账号'
            case BindingType.SINA:
                return '新浪微博';
        }
    }
}

/**
 * 格式化时间
 */
function formatTime(value) {
    return new Date(value).toLocaleString();
}

/**
 * Rest info to html
 */
function restToHtml(rest) {
    var html = '<div style="font-size:.8em;line-height:1.5" class="line-div">';
    // 得分优先考虑 rate, 即用户打分, 然后才是预测打分
    var rated = rest.ugc.rate > 0;
    var rate = rated? rest.ugc.rate: rest.rec.predicted;
    rate = Math.round(rate*10)/10;
    var rateStr;
    if(rated) {
        rateStr = '您的评价: ' + getRateTitle(rate);
    } else {
        rateStr = '可能喜欢: ' + Math.round(rest.rec.predicted*20) + '％';		//因为打分区间是0~5，所以*20
    }
    // 渲染
    //Ext.Msg.alert('rest.brief.name = ' + rest.brief.name);
    html += '<span class="rest-name"><b>' + rest.brief.name + '</b></span><span style="position:absolute;right:20px" class="right-score">' + rateStr + '</span>';//bold
    html += '<p class="line-info">' + rest.brief.style + '，￥' + rest.brief.avgPay;
    html += '，' + rest.brief.city;
    if(rest.rec.dist) {
        html += '，距离：' + rest.rec.dist;
    }
    html += '</p>';
    if(rest.rec.reasons && rest.rec.reasons.length > 0) {
        html += '<p class="line-reason">推荐理由：';	//change
        var n = Math.min(rest.rec.reasons.length, 2);
        
        /*
        for(i = 0; i < n; i ++) {
            html += rest.rec.reasons[i];
            if(i < n-1) {
                html += '，';
            } else if(rest.rec.reasons.length > n) {
                html += '等';
            }
        }
        */
        for(i = 0; i < n; i++) {
        	recStr = rest.rec.reasons[i];
        	arrStr = recStr.split('#');
        	for(j = 0; j < arrStr.length; j++) {
        		if(arrStr[j][0] == '[') {
        			subArrStr = arrStr[j].split(',');
        			if(subArrStr.length == 2) {
        				html += subArrStr[1].substring(0, subArrStr[1].length-1);
        			} else {
        				html += subArrStr[1];
        			}
        		} else {
        			html += arrStr[j];
        		}
        	}
        	if(i < n-1) {
        		html += ', ';
        	} else if(rest.rec.reasons.length > n) {
        		html += '等';
        	}
        }
        
        html += '</p>';
    }
    html += '</div>';
    return html;
}

/**
 * Rest detail to html
 */
function detailToHtml(rest) {
    var html = '<div class="detail-div">';
    // 得分优先考虑 rate, 即用户打分, 然后才是预测打分
    var rated = rest.ugc.rate > 0;
    var rate = rated > 0? rest.ugc.rate: rest.rec.predicted;
    rate = Math.round(rate*10)/10;
    html += '<span class="rest-name"><b>' + rest.brief.name + '</b></span>';
    
    html += '<p>';
    html += '<class="rest-style">' + rest.brief.style + '，￥' + rest.brief.avgPay;
    html += '，' + rest.brief.city;
    if(rest.rec.dist) {
        html += '，距离：' + rest.rec.dist;
    }
    html += '</p>';

    //add useful detail information
    html += '<p>';
    /*
    if(rest.detail.desc) {
    	html += '餐厅描述：' + rest.detail.desc + '<br>';
    }
    */
    if(rest.detail.dishes) {
    	html += '<class="rest-dishes"><b>特色菜：</b>' + rest.detail.dishes + '<br>';
    }
    if(rest.detail.special) {
    	html += '<class="rest-special"><b>餐厅特色：</b>' + rest.detail.special + '<br>';
    }
    if(rest.detail.shophour) {
    	html += '<class="rest-shophour"><b>营业时间：</b>' + rest.detail.shophour + '<br>';
    }
    if(rest.detail.tel) {
    	html += '<calss="rest-tel"><b>联系电话：</b>' + rest.detail.tel + '<br>';
    }
    if(rest.brief.address) {
    	html += '<class="rest-location"><b>地址：</b>' + rest.brief.address;
	}
    html += '</p>';
    
    html += '<p>';
    if(rest.rec.reasons && rest.rec.reasons.length > 0) {
        html += '<class="rec-reason"><b>推荐理由：</b>';
        var n = Math.min(rest.rec.reasons.length, 2);
        
        /*
        for(i = 0; i < n; i ++) {
            html += rest.rec.reasons[i];
            if(i < n-1) {
                html += '，';
            } else if(rest.rec.reasons.length > n) {
                html += '等';
            }
        }
        */
        for(i = 0; i < n; i++) {
        	recStr = rest.rec.reasons[i];
        	arrStr = recStr.split('#');
        	for(j = 0; j < arrStr.length; j++) {
        		if(arrStr[j][0] == '[') {
        			subArrStr = arrStr[j].split(',');
        			if(subArrStr.length == 2) {
        				html += subArrStr[1].substring(0, subArrStr[1].length-1);
        			} else {
        				html += subArrStr[1];
        			}
        		} else {
        			html += arrStr[j];
        		}
        	}
        	if(i < n-1) {
        		html += ', ';
        	} else if(rest.rec.reasons.length > n) {
        		html += '等';
        	}
        }
        html += '<br>';
    }
    if(rated) {
        html += '<class="your-score">您的评价：' + getRateTitle(rest.ugc.rate);
    } else {
        html += '<class="likeness">您喜欢这个餐馆的可能性：' + Math.round(rest.rec.predicted*20) + '％';
    }
    html += '</p>';
    
    html += '</div>';
    return html;
}

/**
 * User info to html
 */
function userInfoToHtml(user) {
    var info = user.getInfo();
    var html = '<div class="user-info">';
    html += '<p>帐号类型：' + (user.isBinded()? '已绑定': '未绑定') + '</p>';
    html += '<p>创建时间：' + formatTime(parseFloat(info.createTime)) + '</p>';
    html += '</div>';
    return html;
}

/**
 * 用户信息
 */
User = function() {
    var info = null;
    /**
     * 加载用户信息
     */
    this.load = function(data) {
        info = data;
    }
    /**
     * 清除用户信息
     */
    this.clear = function() {
        info = null;
    }
    /**
     * 用户信息是否已加载(用户是否登录)
     */
    this.loaded = function() {
        return info != null;
    }
    /**
     * 返回用户信息
     */
    this.getInfo = function() {
        return info;
    }
    /**
     * 用户是否已绑定
     */
    this.isBinded = function() {
        return info && info.bindings && info.bindings.length > 0;
    }
    /**
     * 返回指定类型的绑定帐号, 如果未绑定返回 null
     */
    this.getBindingId = function(type) {
        if(this.isBinded()) {
            for(var i = 0; i < info.bindings.length; i ++) {
                if(info.bindings[i].type == type) {
                    return info.bindings[i].id;
                }
            }
            return null;
        }
    }
}
/**
 * 本地设置
 */
Config = function(name, version, init) {
    var data = null;

    /**
     * load
     */
    var load = function() {
        try {
            data = Ext.decode(localStorage.getItem(name));
            if(data.version != version) {
                throw 'Wrong version';
            }
        } catch(e) {
            data = init(data);
            data.version = version;
        }
    }
    /**
     * save
     */
    var save = function() {
        localStorage.setItem(name, Ext.encode(data));
    }
    /**
     * get
     */
    this.get = function(key) {
        return data[key];
    }
    /**
     * set
     */
    this.set = function(key, value) {
        if(key in data && key != 'version') {
            data[key] = value;
            save();
        } else {
            throw 'Key "' + key + '" does not exist or is read-only';
        }
    }
    /**
     * setAll
     */
    this.setAll = function(config) {
        for(key in config) {
            if(key in data && key != 'version') {
                data[key] = config[key];
            } else {
                throw 'Key "' + key + '" does not exist or is read-only';
            }
        }
        save();
    }
    /**
     * 初始化
     */
    load();
}
/**
 * Mask
 */
Mask = function() {
    var mask = null;
    /**
     * show mask
     */
    this.show = function(element, msg) {
        this.hide();
        if(element) {
            mask = new Ext.LoadMask(element, {
                msg: msg,
            });
            mask.show();
        }
    }
    /**
     * hide mask
     */
    this.hide = function() {
        if(mask) {
            mask.hide();
            mask = null;
        }
    }
}
/**
 * Popup 提示窗口
 */
Msg = {
    overlay: function(title, msg, fn, scope) {
        if(!this.popup) {
            this.popup = new Ext.Panel({
                floating: true,
                modal: true,
                centered: true,
                width: 300,
                height: 200,
                styleHtmlContent: true,
                scroll: 'vertical',
                listeners: {
                    touchstart: {
                        element: 'el',
                        fn: function() {
                            this.popup.hide();
                        },
                        scope: this,
                    }
                },
            });
            this.popup.on('touchstart', 'el', function() {
                console.log(this);
            }, this.popup);
        }
        var html = '';
        if(title) {
            html += '<h3 style="text-align:center">' + title + '</h3>';
        }
        if(msg) {
            html += '<p>' + msg + '</p>';
        }
        this.popup.update(html);
        if(fn) {
            this.popup.on('hide', fn, scope);
        }
        this.popup.show('pop');
    }
};

/**
 * Hook navigator.gelocation for debugging
 */
function hook_geo() {
    var FAKE_POS = {
        coords: {
            longitude: 116.324805,
            latitude: 39.995013,
            accuracy: 80,
        }
    };
    navigator.geolocation.getCurrentPosition = function(successCallback, errorCallback, options) {
        setTimeout( function() {
            successCallback(FAKE_POS);
        }, 500);
    }
    navigator.geolocation.watchPosition = function(successCallback, errorCallback, options) {
        setTimeout( function() {
            successCallback(FAKE_POS);
        }, 500);
        return 1;
    }
    navigator.geolocation.clearWatch = function(watchId) {
    }
}

/**
 * 在Ext库基础上做了扩展:
 *   1. 回调函数可以带一个额外参数
 *   2. [Todo]网络错误处理(基于<script> onError)
 */
JSONP = {

    /**
     * Read-only queue
     * @type Array
     */
    queue: [],

    /**
     * Read-only current executing request
     * @type Object
     */
    current: null,

    /**
     * Make a cross-domain request using JSONP.
     * @param {Object} config
     * Valid configurations are:
     *

     *
     url - {String} - Url to request data from. (required)

     *
     params - {Object} - A set of key/value pairs to be url encoded and passed as GET parameters in the request.

     *
     callbackKey - {String} - Key specified by the server-side provider.

     *
     callback - {Function} - Will be passed a single argument of the result of the request.

     *
     scope - {Scope} - Scope to execute your callback in.

     *
     opt - {Opt} - Optional param for your callback.

     *

     */
    request : function(o) {
        o = o || {};
        if (!o.url) {
            return;
        }

        var me = this;
        o.params = o.params || {};
        if (o.callbackKey) {
            o.params[o.callbackKey] = 'JSONP.callback';
        }
        var params = Ext.urlEncode(o.params);

        var script = document.createElement('script');
        script.type = 'text/javascript';

        this.queue.push({
            url: o.url,
            script: script,
            callback: o.callback ||
            function() {
            },

            scope: o.scope || window,
            params: params || null,
            opt: o.opt || null,
        });

        if (!this.current) {
            this.next();
        }
    },
    // private
    next : function() {
        this.current = null;
        if (this.queue.length) {
            this.current = this.queue.shift();
            this.current.script.src = this.current.url + (this.current.params ? ('?' + this.current.params) : '');
            document.getElementsByTagName('head')[0].appendChild(this.current.script);
        }
    },
    // @private
    callback: function(json) {
        try {
            this.current.callback.call(this.current.scope, json, this.current.opt);
        } finally {
            document.getElementsByTagName('head')[0].removeChild(this.current.script);
            this.next();
        }
    }
};

/**
 *
 *  MD5 (Message-Digest Algorithm)
 *  http://www.webtoolkit.info/
 *
 */
function MD5(string) {

    function RotateLeft(lValue, iShiftBits) {
        return (lValue<<iShiftBits) | (lValue>>>(32-iShiftBits));
    }

    function AddUnsigned(lX,lY) {
        var lX4,lY4,lX8,lY8,lResult;
        lX8 = (lX & 0x80000000);
        lY8 = (lY & 0x80000000);
        lX4 = (lX & 0x40000000);
        lY4 = (lY & 0x40000000);
        lResult = (lX & 0x3FFFFFFF)+(lY & 0x3FFFFFFF);
        if (lX4 & lY4) {
            return (lResult ^ 0x80000000 ^ lX8 ^ lY8);
        }
        if (lX4 | lY4) {
            if (lResult & 0x40000000) {
                return (lResult ^ 0xC0000000 ^ lX8 ^ lY8);
            } else {
                return (lResult ^ 0x40000000 ^ lX8 ^ lY8);
            }
        } else {
            return (lResult ^ lX8 ^ lY8);
        }
    }

    function F(x,y,z) {
        return (x & y) | ((~x) & z);
    }

    function G(x,y,z) {
        return (x & z) | (y & (~z));
    }

    function H(x,y,z) {
        return (x ^ y ^ z);
    }

    function I(x,y,z) {
        return (y ^ (x | (~z)));
    }

    function FF(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(F(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    };

    function GG(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(G(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    };

    function HH(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(H(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    };

    function II(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(I(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    };

    function ConvertToWordArray(string) {
        var lWordCount;
        var lMessageLength = string.length;
        var lNumberOfWords_temp1=lMessageLength + 8;
        var lNumberOfWords_temp2=(lNumberOfWords_temp1-(lNumberOfWords_temp1 % 64))/64;
        var lNumberOfWords = (lNumberOfWords_temp2+1)*16;
        var lWordArray=Array(lNumberOfWords-1);
        var lBytePosition = 0;
        var lByteCount = 0;
        while ( lByteCount < lMessageLength ) {
            lWordCount = (lByteCount-(lByteCount % 4))/4;
            lBytePosition = (lByteCount % 4)*8;
            lWordArray[lWordCount] = (lWordArray[lWordCount] | (string.charCodeAt(lByteCount)<<lBytePosition));
            lByteCount++;
        }
        lWordCount = (lByteCount-(lByteCount % 4))/4;
        lBytePosition = (lByteCount % 4)*8;
        lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80<<lBytePosition);
        lWordArray[lNumberOfWords-2] = lMessageLength<<3;
        lWordArray[lNumberOfWords-1] = lMessageLength>>>29;
        return lWordArray;
    };

    function WordToHex(lValue) {
        var WordToHexValue="",WordToHexValue_temp="",lByte,lCount;
        for (lCount = 0;lCount<=3;lCount++) {
            lByte = (lValue>>>(lCount*8)) & 255;
            WordToHexValue_temp = "0" + lByte.toString(16);
            WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length-2,2);
        }
        return WordToHexValue;
    };

    function Utf8Encode(string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";

        for (var n = 0; n < string.length; n++) {

            var c = string.charCodeAt(n);

            if (c < 128) {
                utftext += String.fromCharCode(c);
            } else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            } else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }

        return utftext;
    };

    var x=Array();
    var k,AA,BB,CC,DD,a,b,c,d;
    var S11=7, S12=12, S13=17, S14=22;
    var S21=5, S22=9 , S23=14, S24=20;
    var S31=4, S32=11, S33=16, S34=23;
    var S41=6, S42=10, S43=15, S44=21;

    string = Utf8Encode(string);

    x = ConvertToWordArray(string);

    a = 0x67452301;
    b = 0xEFCDAB89;
    c = 0x98BADCFE;
    d = 0x10325476;

    for (k=0;k<x.length;k+=16) {
        AA=a;
        BB=b;
        CC=c;
        DD=d;
        a=FF(a,b,c,d,x[k+0], S11,0xD76AA478);
        d=FF(d,a,b,c,x[k+1], S12,0xE8C7B756);
        c=FF(c,d,a,b,x[k+2], S13,0x242070DB);
        b=FF(b,c,d,a,x[k+3], S14,0xC1BDCEEE);
        a=FF(a,b,c,d,x[k+4], S11,0xF57C0FAF);
        d=FF(d,a,b,c,x[k+5], S12,0x4787C62A);
        c=FF(c,d,a,b,x[k+6], S13,0xA8304613);
        b=FF(b,c,d,a,x[k+7], S14,0xFD469501);
        a=FF(a,b,c,d,x[k+8], S11,0x698098D8);
        d=FF(d,a,b,c,x[k+9], S12,0x8B44F7AF);
        c=FF(c,d,a,b,x[k+10],S13,0xFFFF5BB1);
        b=FF(b,c,d,a,x[k+11],S14,0x895CD7BE);
        a=FF(a,b,c,d,x[k+12],S11,0x6B901122);
        d=FF(d,a,b,c,x[k+13],S12,0xFD987193);
        c=FF(c,d,a,b,x[k+14],S13,0xA679438E);
        b=FF(b,c,d,a,x[k+15],S14,0x49B40821);
        a=GG(a,b,c,d,x[k+1], S21,0xF61E2562);
        d=GG(d,a,b,c,x[k+6], S22,0xC040B340);
        c=GG(c,d,a,b,x[k+11],S23,0x265E5A51);
        b=GG(b,c,d,a,x[k+0], S24,0xE9B6C7AA);
        a=GG(a,b,c,d,x[k+5], S21,0xD62F105D);
        d=GG(d,a,b,c,x[k+10],S22,0x2441453);
        c=GG(c,d,a,b,x[k+15],S23,0xD8A1E681);
        b=GG(b,c,d,a,x[k+4], S24,0xE7D3FBC8);
        a=GG(a,b,c,d,x[k+9], S21,0x21E1CDE6);
        d=GG(d,a,b,c,x[k+14],S22,0xC33707D6);
        c=GG(c,d,a,b,x[k+3], S23,0xF4D50D87);
        b=GG(b,c,d,a,x[k+8], S24,0x455A14ED);
        a=GG(a,b,c,d,x[k+13],S21,0xA9E3E905);
        d=GG(d,a,b,c,x[k+2], S22,0xFCEFA3F8);
        c=GG(c,d,a,b,x[k+7], S23,0x676F02D9);
        b=GG(b,c,d,a,x[k+12],S24,0x8D2A4C8A);
        a=HH(a,b,c,d,x[k+5], S31,0xFFFA3942);
        d=HH(d,a,b,c,x[k+8], S32,0x8771F681);
        c=HH(c,d,a,b,x[k+11],S33,0x6D9D6122);
        b=HH(b,c,d,a,x[k+14],S34,0xFDE5380C);
        a=HH(a,b,c,d,x[k+1], S31,0xA4BEEA44);
        d=HH(d,a,b,c,x[k+4], S32,0x4BDECFA9);
        c=HH(c,d,a,b,x[k+7], S33,0xF6BB4B60);
        b=HH(b,c,d,a,x[k+10],S34,0xBEBFBC70);
        a=HH(a,b,c,d,x[k+13],S31,0x289B7EC6);
        d=HH(d,a,b,c,x[k+0], S32,0xEAA127FA);
        c=HH(c,d,a,b,x[k+3], S33,0xD4EF3085);
        b=HH(b,c,d,a,x[k+6], S34,0x4881D05);
        a=HH(a,b,c,d,x[k+9], S31,0xD9D4D039);
        d=HH(d,a,b,c,x[k+12],S32,0xE6DB99E5);
        c=HH(c,d,a,b,x[k+15],S33,0x1FA27CF8);
        b=HH(b,c,d,a,x[k+2], S34,0xC4AC5665);
        a=II(a,b,c,d,x[k+0], S41,0xF4292244);
        d=II(d,a,b,c,x[k+7], S42,0x432AFF97);
        c=II(c,d,a,b,x[k+14],S43,0xAB9423A7);
        b=II(b,c,d,a,x[k+5], S44,0xFC93A039);
        a=II(a,b,c,d,x[k+12],S41,0x655B59C3);
        d=II(d,a,b,c,x[k+3], S42,0x8F0CCC92);
        c=II(c,d,a,b,x[k+10],S43,0xFFEFF47D);
        b=II(b,c,d,a,x[k+1], S44,0x85845DD1);
        a=II(a,b,c,d,x[k+8], S41,0x6FA87E4F);
        d=II(d,a,b,c,x[k+15],S42,0xFE2CE6E0);
        c=II(c,d,a,b,x[k+6], S43,0xA3014314);
        b=II(b,c,d,a,x[k+13],S44,0x4E0811A1);
        a=II(a,b,c,d,x[k+4], S41,0xF7537E82);
        d=II(d,a,b,c,x[k+11],S42,0xBD3AF235);
        c=II(c,d,a,b,x[k+2], S43,0x2AD7D2BB);
        b=II(b,c,d,a,x[k+9], S44,0xEB86D391);
        a=AddUnsigned(a,AA);
        b=AddUnsigned(b,BB);
        c=AddUnsigned(c,CC);
        d=AddUnsigned(d,DD);
    }

    var temp = WordToHex(a)+WordToHex(b)+WordToHex(c)+WordToHex(d);

    return temp.toLowerCase();
}