/**
 * 提供位置服务
 */
Location = function() {
    var geocoder = new google.maps.Geocoder();
    var geoInfo = null;
    var tsinghuaGeoInfo = {
        longitude: 116.3294697,
        latitude: 39.9969109,
        accuracy: 0.1
    };
    var ginZaGeoInfo = {
        longitude: 139.7594006,
        latitude: 35.6684949,
        accuracy: 0.1
    };
    var tokyoStationGeoInfo = {
        longitude: 139.7594864,
        latitude: 35.6749795,
        accuracy: 0.1
    };
    var defaultTokyoGeoInfo = {
        longitude: 139.76524,
        latitude: 35.681683,
        accuracy: 0.1
    };
    var defaultGeoInfo = defaultTokyoGeoInfo;
    var activeGeoInfo = defaultTokyoGeoInfo;
    /* 0 : current, 1: tsinghua, 2:tokyo*/
    var locationIndicator = 2;
    var mask = new Mask();
    var runOnceQueue = [];
    var updateQueue = [];
    var errorQueue = [];

    /**
     * 位置服务
     */
    var geo = new Ext.util.GeoLocation({
        autoUpdate: false,
        allowHighAccuracy: true,
        maximumAge: 5000, // 5 sec
//        timeout: 120000, // 2 min
        timeout: 5000, // 5 sec
        listeners: {
            locationupdate: {
                scope: this,
                fn: function (geo) {
                    if(!geoInfo) {
                        geoInfo = {};
                    }
                    /*EVISON*/
                    //copy_geo(geo, geoInfo);
                    copyLocation();
                    copy_geo(activeGeoInfo, geoInfo);
                    getPosDesc(geoInfo);
                }
            },
            locationerror: {
                scope: this,
                fn: function (geo) {
                    if(!geoInfo) {
                        geoInfo = {};
                    }
                    /*EVISON*/
                    if (locationIndicator == 0) {
                        copy_geo(defaultGeoInfo, geoInfo);
                    } else {
                        copyLocation();
                        copy_geo(activeGeoInfo, geoInfo);
                    }
                    getPosDesc(geoInfo);
                }
            }
            /*EVISON*/
            /*
            locationerror: {
                scope: this,
                fn: function (geo,
                bTimeout,
                bPermissionDenied,
                bLocationUnavailable,
                message) {
                    mask.hide();
                    runQueue(errorQueue,
                    geoInfo,
                    bTimeout,
                    bPermissionDenied,
                    bLocationUnavailable,
                    message);
                    doRunOnce(geoInfo);
                }
            }
            */
        }
    });
    /**
     * 获取地点的文字描述
     */
    var getPosDesc = function(geoInfo) {
        var latlng = new google.maps.LatLng(geoInfo.latitude, geoInfo.longitude);
        geocoder.geocode({
            'latLng': latlng
        }, function(results, status) {
            mask.hide();
            if(status == google.maps.GeocoderStatus.OK && results.length > 0 && results[0].formatted_address) {
                geoInfo.address = results[0].formatted_address;
                runQueue(updateQueue, geoInfo);
            } else {
                runQueue(errorQueue,
                geoInfo,
                false,
                false,
                false,
                '查询当前位置说明失败');
            }
            doRunOnce(geoInfo);
        });
    }
    /**
     * 设定测试位置
     * e = 0: current, e = 1 : Tsinghua, e = 2, defaultTokyo
     */
    var setLocationIndicator = function(e) {
        locationIndicator = e;
    }
    /**
     * 根据locationIndicator来设定位置
    */
    var copyLocation = function() {
        if (locationIndicator == 0) {/*Note: geo可能是空?*/
            copy_geo(geo, activeGeoInfo);
        } else if (locationIndicator == 1) {
            copy_geo(tsinghuaGeoInfo, activeGeoInfo);
        } else if (locationIndicator == 2) {
            copy_geo(defaultTokyoGeoInfo, activeGeoInfo);
        } else {
            copy_geo(geo, activeGeoInfo);
        }
    }
    /**
     * runQueue
     */
    var runQueue = function(queue) {
        var args = Ext.toArray(arguments);
        args.shift();
        for(var i = 0; i < queue.length; i ++) {
            var run = queue[i];
            run.fn.apply(run.scope, args);
        }
    }
    /**
     * addRunOnce
     */
    var addRunOnce = function(runOnce) {
        runOnceQueue.push(runOnce);
    }
    /**
     * doRunOnce
     */
    var doRunOnce = function(geoInfo) {
        runQueue(runOnceQueue, geoInfo);
        runOnceQueue.splice(0);
    }
    /**
     * 设置监听位置更新/失败信息
     */
    this.listen = function(locationupdate, locationerror) {
        if(locationupdate) {
            updateQueue.push(locationupdate);
        }
        if(locationerror) {
            errorQueue.push(locationerror);
        }
    }
    /**
     * 开启服务
     */
    this.open = function() {
        if(!geo.autoUpdate) {
            geo.setAutoUpdate(true);
        }
    }
    /**
     * 关闭服务
     */
    this.close = function() {
        if(geo.autoUpdate) {
            geo.setAutoUpdate(false);
            geoInfo = null;
            geo.fireEvent('locationerror', geo, false, false, false, 'Service closed.');
        }
    }
    /**
     * 更新位置信息
     */
    this.update = function(maskElement) {
        mask.show(maskElement, '正在获取位置信息 ...');
        geo.updateLocation();
    }
    /**
     * 尝试获取位置信息 runOnce(geoInfo)
     */
    this.tryToGet = function(runOnce, scope, maskElement) {
        if(geoInfo) {
            runOnce.call(scope, geoInfo);
        } else {
            addRunOnce({
                fn: runOnce,
                scope: scope
            });
            this.update(maskElement);
        }
    }
}
/**
 * 格式化角度值, 只用于正数
 */
function format_angle(a) {
    d = Math.floor(a);
    a = (a-d)*60;
    m = Math.floor(a);
    a = (a-m)*60;
    s = Math.floor(a);
    return d + "°" + m + "′" + s + "″" ;
}

/**
 * 格式化经纬度值
 */
function format_lola(lo, la) {
    var s;
    if(lo >= 0) {
        s = "东经";
    } else {
        s = "西经";
    }
    s += format_angle(Math.abs(lo)) + " ";
    if(la >= 0) {
        s += "北纬";
    } else {
        s += "南纬";
    }
    s += format_angle(Math.abs(la));
    return s;
}

/**
 * 格式化位置信息
 */
function format_geo(geo) {
    return format_lola(geo.longitude, geo.latitude) + " 精度" + geo.accuracy + "米";
}

/**
 * 拷贝位置信息
 */
function copy_geo(src, dst) {
    dst.longitude = src.longitude;
    dst.latitude = src.latitude;
    dst.accuracy = src.accuracy;
}