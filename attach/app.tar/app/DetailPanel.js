/**
 * 餐馆细节面板
 */
DetailPanel = function(hidden, recommender) {
    /**
     * 面板UI组件
     */
    var detail = new SilmarilDetail({
        rateHandler: {
            fn: function(value) {
                this.rateCurrent(value);
            },
            scope: this,
        }
    });
    var panel = new Ext.Panel({
        height: '100%',
        hidden: hidden,
        dockedItems: [{
            dock : 'top',
            xtype: 'toolbar',
            title: 'Chicker',
            items: [{
                xtype: 'button',
                text: '后退',
                ui: 'back',
                bubbleEvents: 'back',
                handler: function(b, e) {
                    this.fireEvent('back');
                },
            },
            ],
        }
        ],
        items: [detail],
    });

    /**
     * 返回底层的UI组件
     */
    this.getComponent = function() {
        return panel;
    }
    /**
     * show()
     */
    this.show = function(animation) {
        panel.show(animation);
    }
    /**
     * hide()
     */
    this.hide = function(animation) {
        panel.hide(animation);
    }
    /**
     * 更新显示指定餐馆细节
     */
    this.update = function(rest) {
        this.rest = rest;
        detail.update(this.rest);
    }
    /**
     * 为当前餐馆打分
     */
    this.rateCurrent = function(value) {
        var rest = this.rest;
        recommender.rate(rest.brief.id, value, function(data) {
            if(data.status != 0) {
                Ext.Msg.alert('错误', '给' + rest.brief.name + '打分出错了, statuscode = ' + data.status);
            }
        }, this);
    }
}