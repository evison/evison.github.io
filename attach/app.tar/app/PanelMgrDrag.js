/**
 * 管理一组面板的显示和事件等
 */
PanelMgr = function(direction) {
    /**
     * 容器组件
     */
    var panels = new Ext.Carousel({
        fullscreen: true,
        direction: direction,
        indicator: false,
        autoDestroy : false,
        onDrag: function(e) {
            // Stop the drag in the bounds
            var activeIndex = this.items.indexOf(this.layout.activeItem);
            // If this is a horizontal carousel
            if (this.horizontal) {
                if (
                // And we are on the first card and dragging left
                (activeIndex == 0 && e.deltaX > 0) ||
                // Or on the last card and dragging right
                (activeIndex == this.items.length - 1 && e.deltaX < 0)
                ) {
                    return;
                }
            }
            // If this is a vertical carousel
            else if (this.vertical) {
                if (
                // And we are on the first card and dragging up
                (activeIndex == 0 && e.deltaY > 0) ||
                // Or on the last card and dragging down
                (activeIndex == this.items.length - 1 && e.deltaY < 0)
                ) {
                    return;
                }
            }
            // This will update all the cards to their correct position based on the current drag
            Ext.Carousel.prototype.onDrag.apply(this, arguments);
        },
    });
    var items = panels.items;

    /**
     * 显示某个面板
     */
    this.show = function(panel) {
        var item = panel.getComponent();
        var curItem = panels.getActiveItem();
        if(curItem == item) {
            return;
        }
        var curIndex = items.indexOf(curItem);
        if(curIndex < 0) {
            curIndex = -1;
        }
        for(var i = items.length-1; i > curIndex+1; i --) {
            panels.remove(items.getAt(i));
        }
        // 如果当前面板的下一个就是要显示的目标面板, 则做优化
        if(curIndex+1 < items.length) {
            var t = items.getAt(curIndex+1);
            if(t != item) {
                panels.remove(t);
                panels.add(item);
            }
        } else {
            panels.add(item);
        }
        // 这里将子面板的show()与panels.next()分开, 以保证后者的动画效果正确显示
        // 原因不详, 原先猜测跟某些事件有关, 但是跟踪之后发现, 似乎跟特定情况下读取
        // HTMLElement的属性(如offsetHeight)有关, 比较诡异
        item.show();
        setTimeout( function() {
            panels.next();
        }, 0);
    }
    /**
     * 关闭某个面板, 如果参数为null则关闭当前面板
     */
    this.hide = function(panel) {
        var item = panel? panel.getComponent(): panels.getActiveItem();
        if(item) {
            panels.remove(item);
        }
    }
    /**
     * 返回上一个面板
     */
    this.back = function() {
        panels.prev();
    }
    /**
     * 前进到下一个面板
     */
    this.forward = function() {
        panels.next();
    }
    /**
     * 事件绑定
     */
    this.on = function(eventName, handler, scope, options) {
        panels.on(eventName, handler, scope, options);
    }
}
/**
 * 描述面板显示/隐藏动画的方式: 前进
 */
PanelMgr.FORWARD = {
    type: 'slide',
    direction: 'left',
};

/**
 * 描述面板显示/隐藏动画的方式: 后退
 */
PanelMgr.BACK = {
    type: 'slide',
    direction: 'right',
};
/**
 * 描述面板显示/隐藏动画的方式: 向下
 */
PanelMgr.DOWN = {
    type: 'slide',
    direction: 'down',
};

/**
 * 描述面板显示/隐藏动画的方式: 向上
 */
PanelMgr.UP = {
    type: 'slide',
    direction: 'up',
};