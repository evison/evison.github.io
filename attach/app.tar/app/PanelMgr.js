/**
 * 管理一组面板的显示和事件等
 */
PanelMgr = function(direction) {
    /**
     * 容器组件
     */
    var panels = new Ext.Carousel({
        fullscreen: true,
        direction: direction,
        indicator: false,
        autoDestroy : false,
        dragSwitch: true,
        afterRender: function() {
            Ext.Carousel.superclass.afterRender.call(this);

            // Bind the required listeners
            if(this.dragSwitch) {
                this.mon(this.body, {
                    drag: this.onDrag,
                    dragThreshold: 20,
                    dragend: this.onDragEnd,
                    direction: this.direction,
                    scope: this
                });
            }

            this.el.addCls(this.baseCls + '-' + this.direction);
        },
        onDrag: function(e) {
            // Stop the drag in the bounds
            var activeIndex = this.items.indexOf(this.layout.activeItem);
            // If this is a horizontal carousel
            if (this.horizontal) {
                if (
                // And we are on the first card and dragging left
                (activeIndex == 0 && e.deltaX > 0) ||
                // Or on the last card and dragging right
                (activeIndex == this.items.length - 1 && e.deltaX < 0)
                ) {
                    return;
                }
            }
            // If this is a vertical carousel
            else if (this.vertical) {
                if (
                // And we are on the first card and dragging up
                (activeIndex == 0 && e.deltaY > 0) ||
                // Or on the last card and dragging down
                (activeIndex == this.items.length - 1 && e.deltaY < 0)
                ) {
                    return;
                }
            }
            this.currentScroll = {
                x: e.deltaX,
                y: e.deltaY
            };
            // This will update all the cards to their correct position based on the current drag
            this.updateCardPositions();
        },
        /**
         * This determines if we are going to the next card, the previous card, or back to the active card.
         * @private
         */
        onDragEnd : function(e, t) {
            var previousDelta, deltaOffset, minDist,
            box = this.el.getPageBox();

            if (this.horizontal) {
                deltaOffset = e.deltaX;
                minDist = box.width / 3;
            } else {
                deltaOffset = e.deltaY;
                minDist = box.height / 3;
            }

            // We have gone to the right
            if (deltaOffset < 0 && Math.abs(deltaOffset) > minDist && this.layout.getNext()) {
                this.next();
            }
            // We have gone to the left
            else if (deltaOffset > 0 && Math.abs(deltaOffset) > minDist && this.layout.getPrev()) {
                this.prev();
            } else {
                // drag back to current active card
                this.scrollToCard(this.layout.activeItem);
            }
        },
    });
    var items = panels.items;

    /**
     * remove & hide
     */
    var remove = function(item) {
        panels.remove(item);
        item.hide();
    }
    /**
     * remove other items
     */
    var removeOthers = function(item) {
        for(var i = items.length-1; i >= 0; i --) {
            var other = items.getAt(i);
            if(other != item) {
                remove(other);
            }
        }
    }
    /**
     * 显示某个面板
     */
    this.show = function(panel, hideOthers) {
        var item = panel.getComponent();
        var curItem = panels.getActiveItem();
        if(curItem == item) {
            return;
        }
        var curIndex = items.indexOf(curItem);
        if(curIndex < 0) {
            curIndex = -1;
        }
        for(var i = items.length-1; i > curIndex+1; i --) {
            remove(items.getAt(i));
        }
        // 如果当前面板的下一个就是要显示的目标面板, 则做优化
        if(curIndex+1 < items.length) {
            var t = items.getAt(curIndex+1);
            if(t != item) {
                remove(t);
                panels.add(item);
            }
        } else {
            panels.add(item);
        }
        panels.doLayout();
        // 这里将子面板的show()与panels.next()分开, 以保证后者的动画效果正确显示
        // 原因不详, 原先猜测跟某些事件有关, 但是跟踪之后发现, 似乎跟特定情况下读取
        // HTMLElement的属性(如offsetHeight)有关, 比较诡异
        item.show();
        var self = this;
        setTimeout( function() {
            panels.next();
            if(hideOthers) {
                removeOthers(item);
                panels.doLayout();
            }
        }, 0);
    }
    /**
     * 关闭某个面板, 如果参数为null则关闭当前面板
     */
    this.hide = function(panel) {
        var item = panel? panel.getComponent(): panels.getActiveItem();
        if(item) {
            panels.prev();
            remove(item);
            panels.doLayout();
        }
    }
    /**
     * 返回上一个面板
     */
    this.back = function() {
        panels.prev();
    }
    /**
     * 前进到下一个面板
     */
    this.forward = function() {
        panels.next();
    }
    /**
     * 得到当前面板的Index
     */
    this.getActiveIndex = function() {
        return panels.getActiveIndex();
    }
    /**
     * 得到管理中的面板总数
     */
    this.getCount = function() {
        return items.getCount();
    }
    /**
     * 事件绑定
     */
    this.on = function(eventName, handler, scope, options) {
        panels.on(eventName, handler, scope, options);
    }
}
/**
 * 描述面板显示/隐藏动画的方式: 前进
 */
PanelMgr.FORWARD = {
    type: 'slide',
    direction: 'left',
};

/**
 * 描述面板显示/隐藏动画的方式: 后退
 */
PanelMgr.BACK = {
    type: 'slide',
    direction: 'right',
};
/**
 * 描述面板显示/隐藏动画的方式: 向下
 */
PanelMgr.DOWN = {
    type: 'slide',
    direction: 'down',
};

/**
 * 描述面板显示/隐藏动画的方式: 向上
 */
PanelMgr.UP = {
    type: 'slide',
    direction: 'up',
};