/**
 * 对Ext.List进行了扩展, 尾部增加"更多"按钮, 更加方便的数据加载方法
 * config 中增加如下选项:
 *            moreItem: {
 *                handler: handler(this),
 *                scope: scope,
 *                text: text
 *            },
 *            emptyPrompt: text
 */
SilmarilList = Ext.extend(Ext.List, {
    /**
     * constructor
     */
    constructor: function(config) {
        config = Ext.apply({
            hideMore: true,
            moreItem: {
                handler: Ext.emptyFn,
                scope: this,
                text: '更多 ',
            },
            emptyPrompt: '无结果',
        }, config);
        SilmarilList.superclass.constructor.call(this, config);
    },
    /**
     * 重载 refresh 以显示 load more ...
     */
    refresh: function() {
        SilmarilList.superclass.refresh.apply(this, arguments);
        if(!this.hideMore) {
            var targetEl = this.getTargetEl();
            if(!this.moreItem.el) {
                var html = '<div class="x-list-paging-msg">' + this.moreItem.text + '</div>';
                this.moreItem.el = targetEl.createChild({
                    cls: 'x-list-paging',
                    html: html,
                });
                this.mon(this.moreItem.el, 'click', this.moreItem.handler, this.moreItem.scope, this);
            } else {
                targetEl.appendChild(this.moreItem.el);
            }
        }
    },
    /**
     * 加载数据
     */
    loadData: function(data, append, hideMore) {
        this.hideMore = hideMore;
        this.store.loadData(data, append);
        if(this.getCount() == 0) {
            var targetEl = this.getTargetEl();
            if(!this.emptyIndicator) {
                var html = '<div class="x-list-paging-msg">' + this.emptyPrompt + '</div>';
                this.emptyIndicator = targetEl.createChild({
                    cls: 'x-list-paging',
                    html: html,
                });
            } else {
                targetEl.appendChild(this.emptyIndicator);
            }
        }
        if(!append) {
            this.scroller.scrollTo({
                y : 0
            }, false);
        }
    },
    /**
     * 返回 Item Count
     */
    getCount: function() {
        return this.store.getCount();
    }
});