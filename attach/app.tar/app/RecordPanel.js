/**
 * 用户打分记录面板
 */
RecordPanel = function(hidden, recommender) {
    Ext.regModel('RecordList', {
        fields: ['html', 'rateLevel', 'rest']
    });
    /**
     * 面板UI组件
     */
    var recordList = new SilmarilList({
        itemTpl: '{html}',
        store: new Ext.data.Store({
            model: 'RecordList',
            sorters: {
                property : 'rateLevel',
                direction: 'DESC'
            },
            getGroupString : function(record) {
                return RATE_TITLES[record.get('rateLevel')];
            },
        }),
        disableSelection: true,
        grouped: true,
        bubbleEvents: 'detail',
        listeners: {
            itemtap: function(c, index, item, e) {
                this.fireEvent('detail', c.getRecord(item).get('rest'));
            }
        },
        moreItem: {
            handler: function() {
                this.getRecords(true);
            },
            scope: this,
            text: '更多'
        }
    });
    var panel = new Ext.Panel({
        hidden: hidden,
        height: '100%',
        layout: 'fit',
        items: [recordList],
        dockedItems: [{
            dock : 'top',
            xtype: 'toolbar',
            title: 'Chicker',
            items: [{
                xtype: 'button',
                text: '后退',
                ui: 'back',
                bubbleEvents: 'back',
                handler: function(b, e) {
                    this.fireEvent('back');
                },
            },{
                xtype: 'spacer'
            },{
                iconCls: 'refresh',
                iconMask: true,
                ui: 'plain',
                handler: function(b, e) {
                    this.getRecords(false);
                },
                scope: this,
            }
            ],
        }]
    });

    /**
     * 返回底层的UI组件
     */
    this.getComponent = function() {
        return panel;
    }
    /**
     * 获取打分记录
     */
    this.getRecords = function(more) {
        if(typeof this.endRest == 'undefined') {
            this.endRest = null;
        }
        var startTime = null;
        var startPlace = null;
        if(more && this.endRest != null) {
            startTime = this.endRest.time;
            startPlace = this.endRest.id;
        }
        var len = 50;
        recommender.myRates(startTime, startPlace, len, function(data) {
            if(data.status != 0) {
                Ext.Msg.alert('出错了!', 'status = ' + data.status);
                return;
            }
            var rests = data.content.rests;
            if(rests == null) {
                rests = [];
            }
            if(rests.length > 0) {
                this.endRest = rests[rests.length - 1];
            } else if(!more) {
                this.endRest = null;
            }
            var l = [];
            for(var i = 0; i < rests.length; i ++) {
                l.push({
                    html: restToHtml(rests[i]),
                    rateLevel: getRateLevel(rests[i].ugc.rate),	//ugc
                    rest: rests[i],
                });
            }
            recordList.loadData(l, more, l.length < len);
        }, this, panel.body);
    }
    var needRefresh = true;
    /**
     * 设置显示(激活)时刷新
     */
    this.setNeedRefresh = function(b) {
        needRefresh = b;
    }
    /**
     * 初始化
     */
    panel.on('show', function() {
        if(needRefresh) {
            this.getRecords(false);
            needRefresh = false;
        }
    }, this);
}