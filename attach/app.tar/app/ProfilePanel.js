/**
 * 用户选项面板
 */
ProfilePanel = function(hidden, location, recommender) {
    var self = this;
    /**
     * 面板UI组件
     */
    var userInfo = new Ext.Panel();
    var bindings = new Ext.form.FieldSet({
        xtype: 'fieldset',
        title: '帐号绑定',
        defaults: {
            margin: 5,
        },
        initComponent: function() {
            this.ntesCtrl = new BindingControl({
                bindingType: BindingType.NTES,
                bindingId: null,
                bubbleEvents: ['net', 'back'],
                bindHandler: function(b, e) {
                    // bind 而不是 login
                    b.fireEvent('net', false, function() {
                        b.fireEvent('back', true);
                    }, this);
                },
                unbindHandler: function(b, e) {
                    // unbind
                    recommender.unbind(b.bindingType, b.bindingId, function(data) {
                        if(data.status != 0) {
                            Ext.Msg.alert('出错了!', 'status = ' + data.status);
                            return;
                        }
                        CurrentUser.load(data.content);
                        self.refresh();
                    }, this, panel.body);
                },
            });
            this.items = [this.ntesCtrl];
            Ext.form.FieldSet.superclass.initComponent.call(this);
        },
        updateBindings: function(user) {
            // 通行证
            var ntesId = user.getBindingId(BindingType.NTES);
            this.ntesCtrl.updateBinding(BindingType.NTES, ntesId);
        }
    });
    var panel = new Ext.Panel({
        hidden: hidden,
        scroll: 'vertical',
        layout: {
            type: 'fit',
            align: 'center',
            pack: 'center'
        },
        dockedItems: [{
            dock : 'top',
            xtype: 'toolbar',
            title: 'Chicker',
            items: [{
                xtype: 'button',
                text: '后退',
                ui: 'back',
                bubbleEvents: 'back',
                handler: function(b, e) {
                    this.fireEvent('back');
                },
            }]
        }
        ],
        items: [{
            xtype: 'form',
            items: [{
                xtype: 'fieldset',
                title: '用户信息',
                items: userInfo,
            },{
                xtype: 'fieldset',
                title: '个性化',
                items: [{
                    xtype: 'button',
                    margin: 5,
                    text: '我的评分',
                    bubbleEvents: 'record',
                    handler: function(b, e) {
                        this.fireEvent('record');
                    },
                },{
                    xtype: 'button',
                    margin: 5,
                    text: '个性化向导',
                    bubbleEvents: 'personalize',
                    handler: function(b, e) {
                        this.fireEvent('personalize');
                    },
                }
                /*,{
                    xtype: 'button',
                    margin: 5,
                    text: '位置设定:北京清华园周边',
                    bubbleEvents: 'setlocation',
                    handler: function(e) {
                    	//location.setLocationIndicator(1);
						//Ext.Msg.alert('位置设定成功');
                       this.fireEvent('setlocation');
                    },
                }*/
                ]
            },
            bindings]
        }
        ],
    });
    /**
     * 返回底层的UI组件
     */
    this.getComponent = function() {
        return panel;
    }
    /**
     * refresh
     */
    this.refresh = function() {
        userInfo.update(userInfoToHtml(CurrentUser));
        bindings.updateBindings(CurrentUser);
        panel.doComponentLayout();
    }
    /**
     * 初始化
     */
    // 控件事件
    panel.on('activate', function() {
        this.refresh();
    }, this);
    panel.on('render', function() {
        this.refresh();
    }, this);
}
/**
 * 显示一个绑定帐号的状态, 并提供绑定或解除绑定的功能
 * config 中增加如下选项:
 *          bindingType: BindingType.NTES,
 *          bindingId: null,
 *          bindHandler: function(b, e),
 *          unbindHandler: function(b, e),
 *
 */
BindingControl = Ext.extend(Ext.Button, {
    /**
     * constructor
     */
    constructor: function(config) {
        config = Ext.apply({
            bindingType: BindingType.NTES,
            bindingId: null,
            bindHandler: Ext.emptyFn,
            unbindHandler: Ext.emptyFn,
            ui: 'confirm',
        }, config);
        Ext.List.superclass.constructor.call(this, config);
        this.refresh();
    },
    /**
     * refresh
     */
    refresh: function() {
        var typeName = BindingType.getName(this.bindingType);
        if(!this.bindingId) {
            this.setText('绑定' + typeName);
            this.setHandler(this.bindHandler);
        } else {
            this.setText('解除绑定' + typeName + ': ' + this.bindingId);
            this.setHandler(this.unbindHandler);
        }
    },
    /**
     * 更新控件状态
     */
    updateBinding: function(type, id) {
        this.bindingType = type;
        this.bindingId = id;
        this.refresh();
    }
});
