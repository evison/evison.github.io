/**
 * 管理一组面板的显示和事件等
 */
PanelMgr = function(direction) {
    /**
     * 容器组件
     */
    var panels = new Ext.Panel({
        fullscreen: true,
        layout: 'card',
        autoDestroy : false,
    });
    var items = panels.items;

    /**
     * 显示某个面板
     */
    this.show = function(panel) {
        var item = panel.getComponent();
        var curItem = panels.getActiveItem();
        if(curItem == item) {
            return;
        }
        var curIndex = items.indexOf(curItem);
        if(curIndex < 0) {
            curIndex = -1;
        }
        for(var i = items.length-1; i > curIndex+1; i --) {
            panels.remove(items.getAt(i));
        }
        // 如果当前面板的下一个就是要显示的目标面板, 则做优化
        if(curIndex+1 < items.length) {
            var t = items.getAt(curIndex+1);
            if(t != item) {
                panels.remove(t);
                panels.add(item);
            }
        } else {
            panels.add(item);
        }
        item.show();
        this.forward();
    }
    /**
     * 关闭某个面板, 如果参数为null则关闭当前面板
     */
    this.hide = function(panel) {
        var item = panel? panel.getComponent(): panels.getActiveItem();
        if(item) {
            panels.remove(item);
        }
    }
    /**
     * 返回上一个面板
     */
    this.back = function() {
        var prev = panels.layout.getPrev();
        if (prev) {
            panels.setActiveItem(prev, PanelMgr.BACK);
        }
    }
    /**
     * 前进到下一个面板
     */
    this.forward = function() {
        var next = panels.layout.getNext();
        if (next) {
            panels.setActiveItem(next, PanelMgr.FORWARD);
        }
    }
    /**
     * 事件绑定
     */
    this.on = function(eventName, handler, scope, options) {
        panels.on(eventName, handler, scope, options);
    }
}
/**
 * 描述面板显示/隐藏动画的方式: 前进
 */
PanelMgr.FORWARD = {
    type: 'slide',
    direction: 'left',
};

/**
 * 描述面板显示/隐藏动画的方式: 后退
 */
PanelMgr.BACK = {
    type: 'slide',
    direction: 'right',
};
/**
 * 描述面板显示/隐藏动画的方式: 向下
 */
PanelMgr.DOWN = {
    type: 'slide',
    direction: 'down',
};

/**
 * 描述面板显示/隐藏动画的方式: 向上
 */
PanelMgr.UP = {
    type: 'slide',
    direction: 'up',
};