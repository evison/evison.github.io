/**
 * 通行证登录面板
 */
NetPanel = function(hidden, recommender) {
    /**
     * 面板UI组件
     */
    var nameField = new Ext.form.Text({
        name: 'user',
        label: '帐　号',
        margin: 5,
    });
    var passField = new Ext.form.Password({
        name: 'pass',
        label: '密　码',
        margin: 5,
    })
    var panel = new Ext.Panel({
        hidden: hidden,
        // style: {
            // '-webkit-backface-visibility': 'hidden'
        // },
        layout: {
            type: 'vbox',
        },
        dockedItems: [{
            dock : 'top',
            xtype: 'toolbar',
            title: 'Chicker',
            items: [{
                xtype: 'button',
                text: '后退',
                ui: 'back',
                bubbleEvents: 'back',
                handler: function(b, e) {
                    this.fireEvent('back');
                },
            }]
        }
        ],
        items: [{
            xtype: 'form',
            items: [{
                xtype: 'field',
                //html: '使用邮箱帐号登录'
                html: '使用账号登陆'
            }, nameField, passField,{
                text: '登录',
                xtype: 'button',
                ui: 'confirm',
                margin: 5,
                handler: function() {
                    this.login();
                },
                scope: this,
            }
            ]
        }
        ],
    });

    /**
     * 返回底层的UI组件
     */
    this.getComponent = function() {
        return panel;
    }
    /**
     * 设置登录选项, 是否为login, 以及成功后的 callback handler
     */
    this.setOptions = function(isLogin, successHandler, scope) {
        this.isLogin = isLogin;
        this.successHandler = successHandler;
        this.scope = scope;
    }
    /**
     * 登录
     */
    this.login = function() {
        var user = nameField.getValue();
        var pass = passField.getValue();
        this.isLogin = (this.isLogin == true);
        recommender.bindNet(user, pass, this.isLogin, function(data) {
            if(data.status != 0) {
                Ext.Msg.alert('出错了!', 'status = ' + data.status);
                return;
            }
            CurrentUser.load(data.content);
            if(this.successHandler) {
                this.successHandler.call(this.scope);
            }
        }, this, panel.body);
    }
}