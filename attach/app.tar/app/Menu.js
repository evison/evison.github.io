/**
 * 菜单, 增加选项:
 *           items: [{
 *               text: text,
 *               iconCls: iconCls,
 *               handler: handler,
 *               scope: scope,
 *           }]
 */
Menu = Ext.extend(Ext.Component, {
    /**
     * constructor
     */
    constructor: function(config) {
        config = Ext.apply({
            hidden: true,
            floating: true,
            width: '100%',
            style: 'top:auto;bottom:0px;background:#EEEEEE;padding:0px;-webkit-box-shadow:0 -1px 20px black',
            items: [],
        }, config);
        Menu.superclass.constructor.call(this, config);
    },
    /**
     * onRender
     */
    onRender: function() {
        Menu.superclass.onRender.apply(this, arguments);
        var el = this.el;
        for(var i = 0; i < this.items.length; i ++) {
            var item = this.items[i];
            var itemEl = el.createChild({
                style: 'background:#F7F7F7;margin:2px;padding:10px',
                html: '<span class="x-button-label">' + item.text + '</span>',
            });
            // itemEl.createChild({
            // tag: 'img',
            // src: Ext.BLANK_IMAGE_URL,
            // cls: item.iconCls + ' x-icon-mask',
            // });
            this.mon(itemEl, 'click', function(event, el, item) {
                this.hide();
                item.handler.apply(item.scope || this, arguments);
            }, this, item);
        }
    },
    /**
     * show
     */
    show: function() {
        Menu.superclass.show.call(this, {
            type: 'slide',
            direction:'up'
        });
    },
});