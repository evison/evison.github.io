/**
 * 描述餐馆细节, 并提供打分功能
 * config 中增加如下选项:
 *            rateHandler: {
 *                fn: fn(value),
 *                scope: scope,
 *            }
 */
SilmarilDetail = Ext.extend(Ext.Panel, {
    /**
     * constructor
     */
    constructor: function(config) {
        config = Ext.apply({
            rateValue: 0,
            rateHandler: {
                fn: Ext.emptyFn,
                scope: this,
            }
        }, config);
        this.rateCtrl = new Ext.ux.touch.Rating({
            singleColorPerValue: true,
            inputCls : 'x-rating-star-color',
            items : [{
                hoverCls : 'x-rating-0'
            },{
                hoverCls : 'x-rating-1'
            },{
                hoverCls : 'x-rating-2'
            },{
                hoverCls : 'x-rating-3'
            },{
                hoverCls : 'x-rating-4'
            }],
            margin: 5,
            listeners: {
                change: {
                    fn: function(c, value) {
                        config.rateHandler.fn.call(config.rateHandler.scope, value);
                        this.setRate(value, false);
                    },
                    scope: this,
                }
            }
        });
        this.wishToGo = new Ext.Button({
            margin: 2,
            style: {
                "font-size": "80%",
                padding: "1px",
                width: "4em",
                height: "1em",
            },
            text: RATE_TITLES[6],
            ui: 'normal',
            handler: function(b, e) {
                config.rateHandler.fn.call(config.rateHandler.scope, 6);
                this.setRate(6, false);
            },
            scope: this,
        });
        this.notVisited = new Ext.Button({
            margin: 2,
            style: {
                "font-size": "80%",
                padding: "1px",
                width: "4em",
                height: "1em",
            },
            text: RATE_TITLES[0],
            ui: 'normal',
            handler: function(b, e) {
                config.rateHandler.fn.call(config.rateHandler.scope, 0);
                this.setRate(0, false);
            },
            scope: this,
        });
        this.content = new Ext.Panel({
            styleHtmlContent: true,
        });
        config.items = [
          this.content,
          {
            xtype: 'panel',
            layout: 'hbox',
            items: [this.rateCtrl],
          },
          {
            xtype: 'panel',
            layout: 'hbox',
            items: [this.wishToGo, this.notVisited],
          }
        ];
        SilmarilDetail.superclass.constructor.call(this, config);
    },
    /**
     * 更新内容
     */
    update: function(rest) {
        var show = (rest != null);
        this.setVisible(show);
        if(show) {
            var html = detailToHtml(rest);
            this.content.update(html);
            // 得分优先考虑 rate, 即用户打分, 然后才是预测打分
            var rated = rest.ugc.rate > 0;
            var rate = rated? rest.ugc.rate: rest.rec.predicted;
            rate = Math.round(rate*10)/10;
            this.setRate(rate, !rated);
            this.doComponentLayout();
        }
    },
    /**
     * setValue
     */
    setRate: function(value, rec) {
        this.rateValue = value;
        setButtonState(this.wishToGo, value == 6);
        setButtonState(this.notVisited, value == 0);
        if(value == 6) {
            value = 0;
        }
        if(rec) {
            this.rateCtrl.setRecValue(value);
        } else {
            this.rateCtrl.setValue(value);
        }
    },
    /**
     * getRate
     */
    getRate: function() {
        return this.rateValue;
    }
});