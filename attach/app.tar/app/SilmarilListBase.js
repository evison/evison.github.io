/**
 * 对Ext.List进行了扩展, 尾部增加"更多"按钮, 更加方便的数据加载方法
 * config 中增加如下选项:
 *            moreItem: {
 *                handler: handler(this),
 *                scope: scope,
 *                text: text
 *            }
 */
SilmarilList = Ext.extend(Ext.Panel, {
    /**
     * constructor
     */
    constructor: function(config) {
        config = Ext.apply({
            moreItem: {
                handler: Ext.emptyFn,
                scope: this,
                text: '更多 '
            }
        }, config);
        var moreItem = new Ext.Button({
            text: config.moreItem.text,
            margin: 5,
            hidden: true,
            handler: function(b, e) {
                config.moreItem.handler.call(config.moreItem.scope, this);
            },
            scope: this,
        });
        config.scroll = false;
        var list = new Ext.List(config);
        Ext.Panel.superclass.constructor.call(this, {
            scroll: 'vertical',
            moreItem: moreItem,
            store: list.getStore(),
            items:[list, moreItem]
        });
    },
    
    /**
     * 加载数据
     */
    loadData: function(data, append, hideMore) {
        this.store.loadData(data, append);
        if(!append) {
            this.scroller.scrollTo({
                y : 0
            }, false);
        }
        this.moreItem.setVisible(!hideMore);
    },
    
    /**
     * 返回 Item Count
     */
    getCount: function() {
        return this.store.getCount();
    }
});