Ext.setup({
    icon: 'icon.png',
    tabletStartupScreen: 'tablet_startup.png',
    phoneStartupScreen: 'phone_startup.png',
    glossOnIcon: false,
    onReady: function() {
        new Main();
    }
});

/**
 * 主配置
 */
MainConfig = new Config('silmaril', 20111005, function(old) {
    return {
        /*EVISON*/
        //dist: 1000,
        dist: 5000,
        price: 0,
    };
});
/**
 * 当前用户信息
 */
CurrentUser = new User();
/**
 * 主界面, 包含登录界面和功能界面
 */
Main = function() {
    var location = new Location();
    var recommender = new Recommender();
    var panelMgr = new PanelMgr('horizontal');
    var recPanel = new RecPanel(true, location, recommender);
    var detailPanel = new DetailPanel(true, recommender);
    var ratePanel = new RatePanel(true, location, recommender);
    var profilePanel = new ProfilePanel(true, location, recommender);///////
    var recordPanel = new RecordPanel(true, recommender);
    var netPanel = new NetPanel(true, recommender);
    var startPanel = new StartPanel(true, recommender);
    var menu = new Menu({
        items: [{
            text: '设置',
            iconCls: 'settings',
            handler: function() {
                panelMgr.show(profilePanel);
            },
        },{
            text: '注销',
            iconCls: 'settings',
            handler: function() {
                recommender.logout( function(data) {
                    if(data.status != 0) {
                        Ext.Msg.alert('出错了!', 'status = ' + data.status);
                        return;
                    }
                    CurrentUser.clear();
                    panelMgr.show(startPanel, true);
                }, this);
            },
        },{
            text: '退出',
            iconCls: 'settings',
            handler: function() {
                exitApp();
            },
        }]
    });


    //所有fireEvent的函数定义都在这里，对应于一个被强制执行的event
    
    /**
     * 显示开始页
     */
    panelMgr.on('start', function() {
        panelMgr.show(startPanel, true);
    }, this);
    /**
     * 个性化向导
     */
    panelMgr.on('personalize', function(hideOthers) {
        ratePanel.setNeedRefresh(true);
        panelMgr.show(ratePanel, hideOthers == true);
    }, this);
    /**
     * 显示推荐面板
     */
    panelMgr.on('recommend', function(hideOthers) {
        recPanel.setNeedRefresh(true);
        panelMgr.show(recPanel, hideOthers == true);
    }, this);
    /**
     * 显示餐馆细节
     */
    panelMgr.on('detail', function(rest) {
        panelMgr.show(detailPanel);
        detailPanel.update(rest);
    }, this);
    /**
     * 显示用户 profile
     */
    panelMgr.on('profile', function() {
        //panelMgr.show(profilePanel);
        menu.show();
    }, this);
    /**
     * 显示用户打分记录
     */
    panelMgr.on('record', function() {
        recordPanel.setNeedRefresh(true);
        panelMgr.show(recordPanel);
    }, this);
    /**
     * 显示通行证登录面板
     */
    panelMgr.on('net', function(isLogin, successHandler, scope) {
        netPanel.setOptions(isLogin, successHandler, scope);
        panelMgr.show(netPanel);
    }, this);
    /**
     * 后退
     */
    panelMgr.on('back', function(hideCurrent) {
        if(hideCurrent == true) {
            panelMgr.hide();
        } else {
            panelMgr.back();
        }
    }, this);
    /**
     * Phonegap 相关设置
     */
    var doc = Ext.getDoc();
    doc.on('deviceready', function() {
        /**
         * back button
         */
        doc.on('backbutton', function() {
            if(menu.isVisible()) {
                menu.hide();
            } else if(panelMgr.getActiveIndex() <= 0) {
                exitApp();
            } else {
                panelMgr.back();
            }
        }, this);
        /**
         * menu button
         */
        doc.on('menubutton', function() {
            if(CurrentUser.loaded()) {
                menu.setVisible(!menu.isVisible());
            }
        }, this);
    }, this);
    /**
     * 初始化
     */
    panelMgr.show(startPanel, true);
    // 检查用户 是否已登录
    recommender.checkLogin( function(data) {
        if(data.status == 0) {
            CurrentUser.load(data.content);
            panelMgr.show(recPanel, true);
            return;
        } else if(data.status != 4) {
            Ext.Msg.alert('错误', '登录失败, status = ' + data.status);
        }
    }, this, Ext.getBody());
}
