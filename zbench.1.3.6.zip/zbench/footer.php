</div><!--wrapper-->
<div class="clear"></div>
<div id="footer">
	<div id="footer-inside">
		<p>
			<?php _e('Copyright', 'zbench'); ?> &copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?>
			| <?php printf(__('Powered by %1$s and %2$s', 'zbench'), '<a href="http://zww.me">zBench</a>', '<a href="http://wordpress.org/">WordPress</a>'); ?>
		</p>
		<span id="back-to-top">&uarr; <a href="#" rel="nofollow" title="Back to top"><?php _e('Top', 'zbench'); ?></a></span>
	</div>
</div><!--footer-->
<?php wp_footer(); ?>
</body>
</html>